use anyhow::Result;
use egui_file_dialog::FileDialogStorage;
use serde::{Deserialize, Serialize};
use snow_core::mac::{MacModel, NubusDeviceKind};
use std::path::{Path, PathBuf};
use strum::{Display, EnumIter};

/// Generic tri-state preference for an automatic action.
#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq, Default, Display, EnumIter)]
pub enum PromptChoice {
    /// Ask the user every time.
    #[default]
    Ask,
    /// Always perform the action without asking.
    Always,
    /// Never perform the action and don't ask.
    Never,
}

/// Mapping of a right modifier key to the Mac's Cmd key
#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum CmdKeyMapping {
    /// No remapping; right Alt = Option, right Ctrl = Control
    Disabled,
    /// Right Alt maps to Cmd
    #[default]
    RightAlt,
    /// Right Ctrl maps to Cmd
    RightCtrl,
}

const MAX_RECENT_WORKSPACES: usize = 10;
const MAX_RECENT_IMAGES: usize = 10;

#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(default)]
pub struct AppSettings {
    pub recent_workspaces: Vec<PathBuf>,
    pub recent_floppy_images: Vec<PathBuf>,
    pub recent_cd_images: Vec<PathBuf>,
    pub last_roms: Vec<(MacModel, PathBuf)>,
    // Deprecated; now roms_by_card
    #[serde(skip_serializing)]
    pub last_display_roms: Vec<(MacModel, PathBuf)>,
    pub roms_by_card: Vec<(NubusDeviceKind, PathBuf)>,

    pub fd_hdd: FileDialogStorage,
    pub fd_cdrom: FileDialogStorage,
    pub fd_cdrom_files: FileDialogStorage,
    pub fd_floppy: FileDialogStorage,
    pub fd_record: FileDialogStorage,
    pub fd_workspace: FileDialogStorage,
    pub fd_state: FileDialogStorage,
    pub fd_shared_dir: FileDialogStorage,

    pub native_file_dialogs: bool,
    pub hide_mode_toasts: bool,
    pub fastforward_limit_enabled: bool,
    pub fastforward_limit: f64,
    pub dynamic_fastforward: bool,
    pub auto_relative_mouse_fullscreen: bool,
    pub writeback_mode: PromptChoice,
    pub convert_to_moof_mode: PromptChoice,
    /// When true, copy the loaded image to a timestamped sibling file
    /// just before writeback is enabled for it.
    pub backup_on_writeback: bool,
    /// How the right modifier key maps to the Mac's Cmd key
    pub cmd_key_mapping: CmdKeyMapping,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            recent_workspaces: Vec::new(),
            recent_floppy_images: Vec::new(),
            recent_cd_images: Vec::new(),
            last_roms: Vec::new(),
            last_display_roms: Vec::new(),
            roms_by_card: Vec::new(),
            fd_hdd: Default::default(),
            fd_cdrom: Default::default(),
            fd_cdrom_files: Default::default(),
            fd_floppy: Default::default(),
            fd_record: Default::default(),
            fd_workspace: Default::default(),
            fd_state: Default::default(),
            fd_shared_dir: Default::default(),
            native_file_dialogs: false,
            hide_mode_toasts: false,
            fastforward_limit_enabled: false,
            fastforward_limit: 2.0,
            dynamic_fastforward: false,
            auto_relative_mouse_fullscreen: true,
            writeback_mode: PromptChoice::default(),
            convert_to_moof_mode: PromptChoice::default(),
            backup_on_writeback: false,
            cmd_key_mapping: CmdKeyMapping::default(),
        }
    }
}

impl AppSettings {
    fn config_path() -> Result<PathBuf> {
        if let Some(mut config_dir) = dirs::config_dir() {
            config_dir.push("snowemu"); // Add vendor
            config_dir.push("Snow"); // Add application name
            std::fs::create_dir_all(&config_dir)?;
            Ok(config_dir.join("settings.json"))
        } else {
            anyhow::bail!("Could not determine config directory");
        }
    }

    pub fn load() -> Self {
        if let Ok(path) = Self::config_path()
            && let Ok(file) = std::fs::File::open(path)
            && let Ok(settings) = serde_json::from_reader(std::io::BufReader::new(file))
        {
            return settings;
        }
        Default::default()
    }

    pub fn save(&self) {
        if let Err(e) = self.try_save() {
            log::warn!("Failed to save settings: {}", e);
        }
    }

    pub fn try_save(&self) -> Result<()> {
        let path = Self::config_path()?;
        let file = std::fs::File::create(path)?;
        serde_json::to_writer_pretty(file, self)?;
        Ok(())
    }

    pub fn add_recent_workspace(&mut self, path: &Path) {
        let path = if let Ok(p) = path.canonicalize() {
            p
        } else {
            path.to_path_buf()
        };

        self.recent_workspaces.retain(|p| {
            if let Ok(rp) = p.canonicalize() {
                rp != path
            } else {
                *p != path
            }
        });
        self.recent_workspaces.insert(0, path);
        self.recent_workspaces.truncate(MAX_RECENT_WORKSPACES);
        self.save();
    }

    pub fn get_recent_workspaces_for_display(&self) -> Vec<(usize, PathBuf, String)> {
        self.recent_workspaces
            .iter()
            .enumerate()
            .map(|(i, path)| {
                let display_name = path
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .to_string();
                (i + 1, path.clone(), display_name)
            })
            .collect()
    }

    pub fn add_recent_floppy_image(&mut self, path: &Path) {
        let path = if let Ok(p) = path.canonicalize() {
            p
        } else {
            path.to_path_buf()
        };

        self.recent_floppy_images.retain(|p| {
            if let Ok(rp) = p.canonicalize() {
                rp != path
            } else {
                *p != path
            }
        });
        self.recent_floppy_images.insert(0, path);
        self.recent_floppy_images.truncate(MAX_RECENT_IMAGES);
        self.save();
    }

    pub fn add_recent_cd_image(&mut self, path: &Path) {
        let path = if let Ok(p) = path.canonicalize() {
            p
        } else {
            path.to_path_buf()
        };

        self.recent_cd_images.retain(|p| {
            if let Ok(rp) = p.canonicalize() {
                rp != path
            } else {
                *p != path
            }
        });
        self.recent_cd_images.insert(0, path);
        self.recent_cd_images.truncate(MAX_RECENT_IMAGES);
        self.save();
    }

    pub fn set_last_rom(&mut self, model: MacModel, path: &Path) {
        self.last_roms.retain(|(m, _)| *m != model);
        self.last_roms.push((model, path.to_path_buf()));
        self.save();
    }

    pub fn get_last_roms(&self) -> Vec<(MacModel, PathBuf)> {
        self.last_roms.clone()
    }

    pub fn get_last_card_roms(&self) -> Vec<(NubusDeviceKind, PathBuf)> {
        let mut out: Vec<(NubusDeviceKind, PathBuf)> = Vec::new();

        // Migrate deprecated last_display_roms
        if let Some((_, p)) = self.last_display_roms.last() {
            out.push((NubusDeviceKind::Mdc12, p.clone()));
        }

        for (c, p) in &self.roms_by_card {
            out.retain(|(oc, _)| oc != c);
            out.push((*c, p.clone()));
        }
        out
    }

    pub fn set_last_card_rom(&mut self, card: NubusDeviceKind, path: &Path) {
        self.roms_by_card.retain(|(c, _)| *c != card);
        self.roms_by_card.push((card, path.to_path_buf()));
        self.save();
    }

    pub fn get_recent_floppy_images_for_display(&self) -> Vec<(usize, PathBuf, String)> {
        self.recent_floppy_images
            .iter()
            .enumerate()
            .map(|(i, path)| {
                let display_name = path
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .to_string();
                (i + 1, path.clone(), display_name)
            })
            .collect()
    }

    pub fn get_recent_cd_images_for_display(&self) -> Vec<(usize, PathBuf, String)> {
        self.recent_cd_images
            .iter()
            .enumerate()
            .map(|(i, path)| {
                let display_name = path
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .to_string();
                (i + 1, path.clone(), display_name)
            })
            .collect()
    }
}
