# Summary

- [Introduction](./README.md)

# Getting started

- [Obtaining binaries](./getting_started/binaries.md)
- [Building from source](./getting_started/building.md)

# User manual

- [Starting a system](./manual/starting.md)
- [Controlling the emulator](./manual/emulator.md)
- [Working with media](./manual/media/README.md)
    - [Floppies](./manual/media/floppies.md)
    - [Hard drives](./manual/media/harddrives.md)
    - [CD-ROM](./manual/media/cdrom.md)
- [Keyboard/mouse](./manual/input.md)
- [Workspaces](./manual/workspaces.md)
- [File sharing](./manual/sharing.md)
- [Ports](./manual/ports.md)
- [Networking](./manual/network/README.md)
    - [LocalTalk over UDP](./manual/network/ltoudp.md)
    - [Ethernet](./manual/network/ethernet.md)
- [Printing](./manual/printing.md)
- [Fullscreen and Zen mode](./manual/fullscreen.md)
- [Save states](./manual/savestates.md)
- [Debugging](./manual/debugging/README.md)
    - [Breakpoints](./manual/debugging/breakpoints.md)
    - [Registers](./manual/debugging/registers.md)
    - [Disassembly](./manual/debugging/disassembly.md)
    - [Instruction history](./manual/debugging/instruction_history.md)
    - [System trap history](./manual/debugging/trap_history.md)
    - [Peripherals](./manual/debugging/peripherals.md)
    - [Memory viewer](./manual/debugging/memory.md)
    - [Watchpoints](./manual/debugging/watchpoints.md)

# Guides

- [Converting volume disk images](./guides/volume.md)
- [Tap bridge network setups](./guides/tapbridgesetups.md)
