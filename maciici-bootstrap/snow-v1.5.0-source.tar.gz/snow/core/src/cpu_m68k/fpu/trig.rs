use arpfloat::Float;

pub trait FloatTrig {
    fn atan(&self) -> Self;
    fn acos(&self) -> Self;
    fn asin(&self) -> Self;
    fn relative_epsilon(&self, scale: f64) -> Float;

    fn sinh(&self) -> Self;
    fn cosh(&self) -> Self;
    fn tanh(&self) -> Self;
    fn atanh(&self) -> Self;
}

impl FloatTrig for Float {
    fn atan(&self) -> Self {
        // atan(1) = π/4 shortcut
        if self == &Self::one(self.get_semantics(), false) {
            return Self::from_f64(std::f64::consts::FRAC_PI_4).cast(self.get_semantics());
        }

        // Handle special cases
        if self.is_nan() || self.is_zero() {
            return self.clone();
        }

        if self.is_inf() {
            let pi_2 = Self::from_f64(std::f64::consts::FRAC_PI_2).cast(self.get_semantics());
            return if !self.is_negative() {
                pi_2
            } else {
                pi_2.neg()
            };
        }

        // Use the identity: atan(x) = π/2 - atan(1/x) for |x| > 1
        let x = if self.abs() > Self::from_f64(1.0).cast(self.get_semantics()) {
            let recip = Self::from_f64(1.0).cast(self.get_semantics()) / self.clone();
            let result = atan_taylor_series(&recip);
            let pi_2 = Self::from_f64(std::f64::consts::FRAC_PI_2).cast(self.get_semantics());
            return if !self.is_negative() {
                pi_2 - result
            } else {
                pi_2.neg() - result
            };
        } else {
            self.clone()
        };

        atan_taylor_series(&x)
    }

    fn acos(&self) -> Self {
        // Handle special cases
        if self.is_nan() {
            return self.clone();
        }

        let one = Self::one(self.get_semantics(), false);

        // acos(1) = 0
        if self == &one {
            return Self::zero(self.get_semantics(), false);
        }

        // acos(-1) = π
        if self == &one.neg() {
            return Self::from_f64(std::f64::consts::PI).cast(self.get_semantics());
        }

        // |x| > 1 is undefined
        if self.abs() > one {
            return Self::nan(self.get_semantics(), false);
        }

        // acos(x) = atan2(√(1 - x²), x) = atan(√(1 - x²) / x) adjusted for sign
        // Using identity: acos(x) = π/2 - atan(x / √(1 - x²))
        let x_sq = self * self;
        let sqrt_term = (one - x_sq).sqrt();
        let pi_2 = Self::from_f64(std::f64::consts::FRAC_PI_2).cast(self.get_semantics());

        if self.is_zero() {
            return pi_2;
        }

        let ratio = sqrt_term / self.clone();
        let at = ratio.atan();

        if !self.is_negative() {
            at
        } else {
            // For negative x: atan(√(1-x²)/x) is negative, add π
            at + Self::from_f64(std::f64::consts::PI).cast(self.get_semantics())
        }
    }

    fn asin(&self) -> Self {
        // Handle special cases
        if self.is_nan() || self.is_zero() {
            return self.clone();
        }

        let one = Self::one(self.get_semantics(), false);

        // asin(1) = π/2
        if self == &one {
            return Self::from_f64(std::f64::consts::FRAC_PI_2).cast(self.get_semantics());
        }

        // asin(-1) = -π/2
        if self == &one.neg() {
            return Self::from_f64(std::f64::consts::FRAC_PI_2)
                .cast(self.get_semantics())
                .neg();
        }

        // |x| > 1 is undefined
        if self.abs() > one {
            return Self::nan(self.get_semantics(), false);
        }

        // asin(x) = atan(x / √(1 - x²))
        let x_sq = self * self;
        let sqrt_term = (one - x_sq).sqrt();
        let ratio = self.clone() / sqrt_term;
        ratio.atan()
    }

    fn relative_epsilon(&self, scale: f64) -> Float {
        self.abs() * Self::from_f64(scale).cast(self.get_semantics())
    }

    fn sinh(&self) -> Self {
        let e = Self::e(self.get_semantics());

        (e.pow(self) - e.pow(&self.neg())) / 2
    }

    fn cosh(&self) -> Self {
        if self.is_zero() {
            return Self::one(self.get_semantics(), false);
        }

        let x = self.abs();
        let e = Self::e(self.get_semantics());
        (e.pow(&x) + e.pow(&x.neg())) / 2
    }

    fn tanh(&self) -> Self {
        self.sinh() / self.cosh()
    }

    fn atanh(&self) -> Self {
        // ½ × ln((1 + x)/(1 - x))
        let one = Self::one(self.get_semantics(), false);
        let two = Self::from_u64(self.get_semantics(), 2);
        ((one.clone() + self.clone()) / (one - self.clone())).log() / two
    }
}

fn atan_taylor_series(x: &Float) -> Float {
    // Taylor series: atan(x) = x - x³/3 + x⁵/5 - x⁷/7 + ...
    // Valid for |x| ≤ 1

    let mut result = x.clone();
    let mut term = x.clone();
    let x_squared = x * x;

    // Iterate until convergence (when term becomes negligible)
    // Maximum 50 iterations to prevent infinite loops
    for i in 1..50 {
        term *= &x_squared;
        let denominator = Float::from_f64((2 * i + 1) as f64).cast(x.get_semantics());
        let current_term = &term / denominator;

        if i % 2 == 0 {
            result += &current_term;
        } else {
            result -= &current_term;
        }

        // Check for convergence - if the term is very small relative to result
        if current_term.abs() < x.relative_epsilon(1e-15) {
            break;
        }
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_atan_basic_values() {
        // Test zero
        let zero = Float::from_f64(0.0);
        assert_eq!(zero.atan().as_f64(), 0.0);

        // Test positive and negative one
        let one = Float::from_f64(1.0);
        let neg_one = Float::from_f64(-1.0);
        let expected_pi_4 = std::f64::consts::FRAC_PI_4;

        let one_result = one.atan().as_f64();
        let neg_one_result = neg_one.atan().as_f64();

        assert!((one_result - expected_pi_4).abs() < 1e-2);
        assert!((neg_one_result + expected_pi_4).abs() < 1e-2);
    }

    #[test]
    fn test_atan_comparison_with_std() {
        let test_values = [
            0.0, 0.1, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0, -0.1, -0.5, -0.7, -1.0, -1.5, -2.0,
            -3.0, -5.0, -10.0, 0.001, 0.999, 1.001, 100.0, -100.0,
        ];

        for &value in &test_values {
            let float_val = Float::from_f64(value);
            let my_result = float_val.atan().as_f64();
            let std_result = value.atan();

            let error = (my_result - std_result).abs();
            // Adjust tolerance based on the simpler Taylor series implementation
            let tolerance = if value.abs() >= 1.0 || (value.abs() - 1.0).abs() < 0.01 {
                1e-2
            } else {
                1e-3
            };
            assert!(
                error < tolerance,
                "Value: {}, My result: {}, Std result: {}, Error: {}",
                value,
                my_result,
                std_result,
                error
            );
        }
    }

    #[test]
    fn test_atan_special_cases() {
        // Test positive infinity
        let pos_inf = Float::from_f64(f64::INFINITY);
        assert_eq!(pos_inf.atan().as_f64(), std::f64::consts::FRAC_PI_2);

        // Test negative infinity
        let neg_inf = Float::from_f64(f64::NEG_INFINITY);
        assert_eq!(neg_inf.atan().as_f64(), -std::f64::consts::FRAC_PI_2);

        // Test NaN
        let nan = Float::from_f64(f64::NAN);
        assert!(nan.atan().is_nan());
    }

    #[test]
    fn test_atan_precision_comparison() {
        // Test values where Taylor series convergence is important
        let precise_values = [
            0.123456789,
            0.987654321,
            1.23456789,
            std::f64::consts::E,
            std::f64::consts::PI,
            -0.123456789,
            -0.987654321,
            -1.23456789,
        ];

        for &value in &precise_values {
            let float_val = Float::from_f64(value);
            let my_result = float_val.atan().as_f64();
            let std_result = value.atan();

            let error = (my_result - std_result).abs();
            let tolerance = if (value.abs() - 1.0).abs() < 0.02 {
                1e-2
            } else {
                1e-3
            };
            assert!(
                error < tolerance,
                "Value: {}, My result: {}, Std result: {}, Error: {}",
                value,
                my_result,
                std_result,
                error
            );
        }
    }

    #[test]
    fn test_acos() {
        let tolerance = 1e-2;
        for i in -1000..=1000 {
            let f = f64::from(i) / 1000.0;
            let me = Float::from_f64(f).acos().as_f64();
            let std = f.acos();
            let error = (me - std).abs();
            assert!(
                error < tolerance,
                "Value: {}, My result: {}, Std result: {}, Error: {}",
                f,
                me,
                std,
                error
            );
        }
    }

    #[test]
    fn test_acos_special_cases() {
        // acos(1) = 0
        let one = Float::from_f64(1.0);
        assert_eq!(one.acos().as_f64(), 0.0);

        // acos(-1) = π
        let neg_one = Float::from_f64(-1.0);
        assert!((neg_one.acos().as_f64() - std::f64::consts::PI).abs() < 1e-10);

        // acos(0) = π/2
        let zero = Float::from_f64(0.0);
        assert!((zero.acos().as_f64() - std::f64::consts::FRAC_PI_2).abs() < 1e-10);

        // acos(NaN) = NaN
        let nan = Float::from_f64(f64::NAN);
        assert!(nan.acos().is_nan());

        // acos(1.5) = NaN (out of domain)
        let out = Float::from_f64(1.5);
        assert!(out.acos().is_nan());
    }

    #[test]
    fn test_asin() {
        let tolerance = 1e-2;
        for i in -1000..=1000 {
            let f = f64::from(i) / 1000.0;
            let me = Float::from_f64(f).asin().as_f64();
            let std = f.asin();
            let error = (me - std).abs();
            assert!(
                error < tolerance,
                "Value: {}, My result: {}, Std result: {}, Error: {}",
                f,
                me,
                std,
                error
            );
        }
    }

    #[test]
    fn test_asin_special_cases() {
        // asin(0) = 0
        let zero = Float::from_f64(0.0);
        assert_eq!(zero.asin().as_f64(), 0.0);

        // asin(1) = π/2
        let one = Float::from_f64(1.0);
        assert!((one.asin().as_f64() - std::f64::consts::FRAC_PI_2).abs() < 1e-10);

        // asin(-1) = -π/2
        let neg_one = Float::from_f64(-1.0);
        assert!((neg_one.asin().as_f64() + std::f64::consts::FRAC_PI_2).abs() < 1e-10);

        // asin(NaN) = NaN
        let nan = Float::from_f64(f64::NAN);
        assert!(nan.asin().is_nan());

        // asin(1.5) = NaN (out of domain)
        let out = Float::from_f64(1.5);
        assert!(out.asin().is_nan());
    }

    #[test]
    fn test_sinh() {
        let tolerance = 1e-6;
        for i in -2000..2000 {
            let f = f64::from(i) / 100.0;
            let me = Float::from_f64(f).sinh().as_f64();
            let std = f.sinh();
            let error = (me - std).abs();
            eprintln!("{} me: {} std: {} error: {}", f, me, std, error);
            assert!(error < tolerance);
        }
    }

    #[test]
    fn test_cosh() {
        let tolerance = 1e-6;
        for i in -2000..2000 {
            let f = f64::from(i) / 100.0;
            let me = Float::from_f64(f).cosh().as_f64();
            let std = f.cosh();
            let error = (me - std).abs();
            eprintln!("{} me: {} std: {} error: {}", f, me, std, error);
            assert!(error < tolerance);
        }
    }

    #[test]
    fn test_tanh() {
        let tolerance = 1e-6;
        for i in -2000..2000 {
            let f = f64::from(i) / 100.0;
            let me = Float::from_f64(f).tanh().as_f64();
            let std = f.tanh();
            let error = (me - std).abs();
            eprintln!("{} me: {} std: {} error: {}", f, me, std, error);
            assert!(error < tolerance);
        }
    }

    #[test]
    fn test_atanh() {
        let tolerance = 1e-12;
        for i in -999..999 {
            let f = f64::from(i) / 1000.0;
            let me = Float::from_f64(f).atanh().as_f64();
            let std = f.atanh();
            let error = (me - std).abs();
            eprintln!("{} me: {} std: {} error: {}", f, me, std, error);
            assert!(error < tolerance);
        }
    }
}
