//! SCSI controller, devices and associated code

pub mod cdrom;
pub mod controller;
pub mod disk;
pub mod disk_image;
#[cfg(feature = "ethernet")]
pub mod ethernet;
#[cfg(feature = "printer")]
pub mod printer;
pub mod target;
pub mod toolbox;

pub const STATUS_GOOD: u8 = 0;
pub const STATUS_CHECK_CONDITION: u8 = 2;

pub const CC_KEY_NOT_READY: u8 = 0x02;
pub const CC_KEY_MEDIUM_ERROR: u8 = 0x03;
pub const CC_KEY_ILLEGAL_REQUEST: u8 = 0x05;

pub const ASC_UNRECOVERED_READ_ERROR: u16 = 0x1100;
pub const ASC_PARAMETER_LIST_LENGTH_ERROR: u16 = 0x1A00;
pub const ASC_INVALID_COMMAND: u16 = 0x2000;
pub const ASC_LOGICAL_BLOCK_ADDRESS_OUT_OF_RANGE: u16 = 0x2100;
pub const ASC_INVALID_FIELD_IN_CDB: u16 = 0x2400;
pub const ASC_MEDIUM_NOT_PRESENT: u16 = 0x3A00;
pub const ASC_ILLEGAL_MODE_FOR_THIS_TRACK: u16 = 0x6400;

const fn scsi_cmd_len(cmdnum: u8) -> Option<usize> {
    match cmdnum {
        // UNIT READY
        0x00
        // REZERO UNIT
        | 0x01
        // REQUEST SENSE
        | 0x03
        // FORMAT UNIT (Direct Access), FORMAT (Printer)
        | 0x04
        // Non-standard (LaserWriter data transfer command)
        | 0x05
        // Non-standard (LaserWriter setup command)
        | 0x06
        // READ(6)
        | 0x08
        // Non-standard (stats for Ethernet)
        | 0x09
        // WRITE(6) (Storage), PRINT (Printer)
        | 0x0A
        // Non-standard (multicast mutation for Ethernet)
        | 0x0D
        // Non-standard (enable interface for Ethernet)
        | 0x0E
        // INQUIRY
        | 0x12
        // MODE SELECT(6)
        | 0x15
        // MODE SENSE(6)
        | 0x1A
        // START/STOP UNIT
        | 0x1B
        // PREVENT/ALLOW MEDIA REMOVAL
        | 0x1E
        // VENDOR SPECIFIC (EJECT)
        | 0xC0
        => Some(6),
        // READ CAPACITY(10)
        0x25
        // READ(10)
        | 0x28
        // WRITE(10)
        | 0x2A
        // VERIFY(10)
        | 0x2F
        // READ BUFFER(10)
        | 0x3C
        // READ SUB-CHANNEL
        | 0x42
        // READ TOC
        | 0x43
        // PLAY AUDIO MSF
        | 0x47
        // PAUSE/RESUME
        | 0x4B
        // READ DISC INFORMATION
        | 0x51
        // MODE SENSE(10)
        | 0x5A
        // AUDIO SCAN (1)
        | 0xCD
        // BlueSCSI Toolbox commands
        | 0xD0..=0xD9
        => Some(10),
        // REPORT KEY
        0xA4
        // READ DVD STRUCTURE
        | 0xAD
        => Some(12),
        _ => {
            None
        }
    }
}

/// Result of a command
pub(crate) enum ScsiCmdResult {
    /// Immediately turn to the Status phase
    Status(u8),
    /// Returns data to the initiator
    DataIn(Vec<u8>),
    /// Expects data written to target
    DataOut(usize),
}
