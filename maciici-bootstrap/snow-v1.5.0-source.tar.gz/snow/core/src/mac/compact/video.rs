//! CRT video handling module
//!
//! Code here deals with the timings of the CRTs and video circuitry of the original
//! compact Macs (128K, 512K, SE, Classic).
//!
//! ## Timing
//! Video runs off a 15.667 MHz pixel clock, which is a multiple of 2 from the CPU
//! clock.
//! Many clocks and timings are branched off (with divisors) from the pixel clock
//! or synced to the blanking periods. For example:
//!  - A sound sample is loaded on HBlank.
//!  - Disk drive spindle motor speed PWM is loaded on HBlank.
//!
//! The effective screen refresh rate is 60.14 Hz.
//!
//! ## Shared RAM access for frame buffer
//! The video framebuffer lives in main system RAM. This means access to the RAM is
//! shared between the audio/video circuitry and the main CPU. While the video
//! circuitry is accessing the RAM, the memory controller de-asserts DTACK if the
//! CPU accesses RAM, making the CPU insert wait states.
//!
//! ## Frame buffer layout
//! The framebuffer has a simple 1-bit-per-pixel layout. The MSbit is the left-most
//! pixel. A zero indicates a white pixel, a one indicates a black pixel.
//!
//! ## Frame Layout
//!  - VBlank: 28 lines (0 to 27)
//!  - Visible Area: 342 lines (28 to 369)
//!  - Visible dots: 512 dots per scanline (only in the visible area)
//!  - HBlank: 192 dots per scanline (at the end of each scanline)
//!
//! +------------------------------- CRT Frame -------------------------------+
//! |                              VBlank (28 lines)                          |
//! |   +------------------------------- Scanline 0 ------------------------+ |
//! |   |        No Visible Dots (VBlank)        | HBlank (192 dots)        | |
//! |   +------------------------------- Scanline 1 ------------------------+ |
//! |   |        No Visible Dots (VBlank)        | HBlank (192 dots)        | |
//! |   +------------------------------- Scanline 2 ------------------------+ |
//! |   |        No Visible Dots (VBlank)        | HBlank (192 dots)        | |
//! |   ... (28 total lines of vertical blanking)                             |
//! |   +------------------------------- Scanline 27 -----------------------+ |
//! |   |        No Visible Dots (VBlank)        | HBlank (192 dots)        | |
//! |                             Visible Area (342 lines)                    |
//! |   +------------------------------- Scanline 28 -----------------------+ |
//! |   |      Visible (512 dots)             | HBlank (192 dots)           | |
//! |   +------------------------------- Scanline 29 -----------------------+ |
//! |   |      Visible (512 dots)             | HBlank (192 dots)           | |
//! |   +------------------------------- Scanline 30 -----------------------+ |
//! |   |      Visible (512 dots)             | HBlank (192 dots)           | |
//! |                                                                         |
//! |   ... (repeat for 342 visible lines)                                    |
//! |                                                                         |
//! |   +------------------------------- Scanline 369 ----------------------+ |
//! |   |      Visible (512 dots)             | HBlank (192 dots)           | |
//! +-------------------------------------------------------------------------+

use crate::bus::Address;
use crate::debuggable::Debuggable;
use crate::renderer::Renderer;
use crate::tickable::{Tickable, Ticks};
use crate::types::LatchingEvent;

use anyhow::Result;
use serde::{Deserialize, Serialize};

/// Visible dots in one scanline
const H_VISIBLE_DOTS: usize = 512;

/// Length of HBlank, in dots.
const HBLANK_DOTS: usize = 192;

/// Total scanline length, including HBlank, in dots.
const H_DOTS: usize = H_VISIBLE_DOTS + HBLANK_DOTS;

/// Visible lines in one frame
const V_VISIBLE_LINES: usize = 342;

/// Length of VBlank, in lines.
const VBLANK_LINES: usize = 28;

/// Total scanlines, including VBlank.
const V_LINES: usize = V_VISIBLE_LINES + VBLANK_LINES;

/// Total dots in one frame, including blanking periods.
const FRAME_DOTS: usize = H_DOTS * V_LINES;

/// Total visible dots in one frame.
const FRAME_VISIBLE_DOTS: usize = H_VISIBLE_DOTS * V_VISIBLE_LINES;

/// Offset in dots of where the visible area begins.
const FRAME_VISIBLE_OFFSET: usize = VBLANK_LINES * H_DOTS;

/// Size (in bytes) of a single framebuffer.
pub const FRAMEBUFFER_SIZE: usize = FRAME_DOTS / 8;

/// Offset of main framebuffer (from END of RAM)
pub const FRAMEBUFFER_MAIN_OFFSET: Address = 0xD900;

/// Offset of alternate framebuffer (from END of RAM)
pub const FRAMEBUFFER_ALT_OFFSET: Address = 0x5900;

/// CRT/video circuitry state
#[derive(Serialize, Deserialize)]
#[serde(bound = "")]
pub struct Video<T: Renderer> {
    #[serde(skip)]
    pub renderer: Option<T>,

    /// Absolute beam position
    dots: Ticks,

    /// Latch for entered VBlank
    event_vblank: LatchingEvent,

    /// Latch for entered HBlank
    event_hblank: LatchingEvent,

    /// Primary and alternate framebuffer
    pub framebuffers: [Vec<u8>; 2],

    /// Video page to be used by video circuitry
    /// (true = main, false = alternate)
    /// (lives in VIA, copied here)
    pub framebuffer_select: bool,

    /// Debug mode: both framebuffers
    pub debug_framebuffers: bool,
}

impl<T> Video<T>
where
    T: Renderer,
{
    /// Tests if currently in any blanking period.
    pub fn in_blanking_period(&self) -> bool {
        self.in_hblank() || self.in_vblank()
    }

    /// Tests if currently in VBlank period.
    pub fn in_vblank(&self) -> bool {
        self.dots < FRAME_VISIBLE_OFFSET as u64
    }

    /// Tests if currently in HBlank period (also during VBlank)
    pub fn in_hblank(&self) -> bool {
        self.dots % H_DOTS as u64 >= H_VISIBLE_DOTS as u64
    }

    /// Gets the current active scanline
    pub fn get_scanline(&self) -> usize {
        (self.dots / H_DOTS as u64).try_into().unwrap()
    }

    /// Gets the current scanline, offset from the top of the visible frame.
    pub fn get_visible_scanline(&self) -> Option<usize> {
        if self.in_vblank() {
            None
        } else {
            Some(self.get_scanline() - VBLANK_LINES)
        }
    }

    pub fn new(renderer: T) -> Self {
        Self {
            renderer: Some(renderer),
            dots: 0,
            event_vblank: LatchingEvent::default(),
            event_hblank: LatchingEvent::default(),
            framebuffers: [vec![0xFF; FRAMEBUFFER_SIZE], vec![0xFF; FRAMEBUFFER_SIZE]],
            framebuffer_select: false,
            debug_framebuffers: false,
        }
    }

    /// Reads and clears 'entered vblank' latch
    pub fn get_clr_vblank(&mut self) -> bool {
        self.event_vblank.get_clear()
    }

    /// Reads and clears 'entered hblank' latch
    pub fn get_clr_hblank(&mut self) -> bool {
        self.event_hblank.get_clear()
    }

    #[inline(always)]
    fn render_buf_to<const LINE_LIMIT: usize, const LINE_OFFSET: usize>(
        fb: &[u8],
        buf: &mut [u8],
        white: u8,
        black: u8,
    ) {
        for i in 0..FRAME_VISIBLE_DOTS {
            let scanline = i / H_VISIBLE_DOTS;
            let byte = i / 8;
            let bit = i % 8;
            let out_offset = if LINE_LIMIT > 0 {
                ((scanline * (LINE_LIMIT * 2)) + LINE_OFFSET + (i % LINE_LIMIT)) * 4
            } else {
                i * 4
            };

            if fb[byte] & (1 << (7 - bit)) == 0 {
                buf[out_offset] = white;
                buf[out_offset + 1] = white;
                buf[out_offset + 2] = white;
            } else {
                buf[out_offset] = black;
                buf[out_offset + 1] = black;
                buf[out_offset + 2] = black;
            }
            buf[out_offset + 3] = 0xFF;
        }
    }

    /// Prepares the image and sends it to the frontend renderer
    pub fn render(&mut self) -> Result<()> {
        const WHITE: u8 = 0xEE;
        const DIM: u8 = 0x99;
        const BLACK: u8 = 0x22;

        let renderer = self.renderer.as_mut().unwrap();
        let buf = renderer.buffer_mut();

        if self.debug_framebuffers {
            buf.set_size(H_VISIBLE_DOTS * 2, V_VISIBLE_LINES);
            Self::render_buf_to::<{ H_VISIBLE_DOTS }, 0>(
                &self.framebuffers[0],
                buf,
                if !self.framebuffer_select { WHITE } else { DIM },
                BLACK,
            );
            Self::render_buf_to::<{ H_VISIBLE_DOTS }, { H_VISIBLE_DOTS }>(
                &self.framebuffers[1],
                buf,
                if self.framebuffer_select { WHITE } else { DIM },
                BLACK,
            );
        } else {
            buf.set_size(H_VISIBLE_DOTS, V_VISIBLE_LINES);

            let fb = if !self.framebuffer_select {
                &self.framebuffers[0]
            } else {
                &self.framebuffers[1]
            };
            Self::render_buf_to::<0, 0>(fb, buf, WHITE, BLACK);
        }

        renderer.update()?;

        Ok(())
    }

    /// Blanks the display and sends an update to the renderer.
    pub fn blank(&mut self) -> Result<()> {
        self.framebuffers.iter_mut().for_each(|b| b.fill(0xFF));
        self.render()
    }
}

impl<T> Tickable for Video<T>
where
    T: Renderer,
{
    fn tick(&mut self, ticks: Ticks, _: ()) -> Result<Ticks> {
        // Simulate ticks one-at-a-time to ensure we don't miss a vblank or hblank.
        for _ in 0..ticks {
            let before_vblank = self.in_vblank();
            let before_hblank = self.in_hblank();

            // Update beam position
            self.dots = (self.dots + 1) % FRAME_DOTS as u64;

            if !before_vblank && self.in_vblank() {
                // Just entered VBlank
                self.event_vblank.set();
            }

            if !before_hblank && self.in_hblank() {
                // Just entered HBlank
                self.event_hblank.set();
            }

            if before_vblank && !self.in_vblank() {
                // Just left VBlank
                self.render()?;
            }
        }

        Ok(ticks)
    }
}

impl<T> Debuggable for Video<T>
where
    T: Renderer,
{
    fn get_debug_properties(&self) -> crate::debuggable::DebuggableProperties {
        use crate::debuggable::*;
        use crate::{dbgprop_bool, dbgprop_header, dbgprop_str, dbgprop_udec};

        vec![
            dbgprop_str!(
                "Active framebuffer",
                if self.framebuffer_select {
                    "Primary"
                } else {
                    "Alternate"
                }
            ),
            dbgprop_bool!("In VBlank", self.in_vblank()),
            dbgprop_bool!("In HBlank", self.in_hblank()),
            dbgprop_header!("Beam position"),
            dbgprop_udec!("Horizontal", self.dots % H_DOTS as u64),
            dbgprop_udec!("Vertical", self.get_scanline()),
        ]
    }
}

#[cfg(test)]
mod tests {
    use crate::renderer::NullRenderer;

    use super::*;

    fn video() -> Video<NullRenderer> {
        Video::new(NullRenderer::new(0, 0).unwrap())
    }

    #[test]
    fn vblank_period() {
        let mut v = video();

        // Scanline 0 - 27 is VBlank
        assert_eq!(v.get_scanline(), 0);
        assert!(v.in_vblank());

        // Last dot in VBlank
        v.tick((28 * (512 + 192)) - 1, ()).unwrap();
        assert!(v.in_vblank());
        assert_eq!(v.get_scanline(), 27);

        // Exit VBlank
        v.tick(1, ()).unwrap();
        assert_eq!(v.get_scanline(), 28);
        assert!(!v.in_vblank());
        assert!(!v.get_clr_vblank());

        // Last dot in visible area before next VBlank
        v.tick((342 * (512 + 192)) - 1, ()).unwrap();
        assert_eq!(v.get_scanline(), 369);
        assert!(!v.in_vblank());
        assert!(!v.get_clr_vblank());

        // Enter VBlank
        v.tick(1, ()).unwrap();
        assert_eq!(v.get_scanline(), 0);
        assert!(v.in_vblank());
        assert!(v.get_clr_vblank());
        assert_eq!(v.dots, 0);
    }

    #[test]
    fn hblank_period() {
        let mut v = video();

        for _ in 0..370 {
            assert!(!v.in_hblank());
            v.tick(512, ()).unwrap();
            assert!(v.in_hblank());
            v.tick(192, ()).unwrap();
        }
    }
}
