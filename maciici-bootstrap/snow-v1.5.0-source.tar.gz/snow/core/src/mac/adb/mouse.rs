use std::collections::VecDeque;

use crate::{mac::adb::AdbEvent, types::MouseEvent, util::take_from_accumulator};

use super::{AdbDevice, AdbDeviceResponse, AdbReg3};

use log::*;
use proc_bitfield::bitfield;
use serde::{Deserialize, Serialize};

bitfield! {
    /// Talk Register 0
    #[derive(Clone, Copy, PartialEq, Eq, Default)]
    pub struct AdbMouseReg0(pub u16): Debug, FromStorage, IntoStorage, DerefStorage {
        /// Buffered relative X motion
        pub x: i8 @ 0..=6,
        /// Buffered relative Y motion
        pub y: i8 @ 8..=14,
        /// Primary button (inverted)
        pub btn: bool @ 15,
    }
}

const MAX_REL_MOVE: i32 = 31;
const MOUSE_FACTOR: i32 = 1;

/// Apple Desktop Bus-connected mouse
#[derive(Serialize, Deserialize)]
pub struct AdbMouse {
    address: u8,
    handler_id: u8,

    event_queue: VecDeque<MouseEvent>,

    button: bool,
    rel_move_x: i32,
    rel_move_y: i32,
}

impl AdbMouse {
    pub const INITIAL_ADDRESS: u8 = 3;
    pub const INITIAL_HANDLER_ID: u8 = 1;

    pub fn new() -> Self {
        Self {
            event_queue: VecDeque::new(),
            address: Self::INITIAL_ADDRESS,
            handler_id: Self::INITIAL_HANDLER_ID,
            button: false,
            rel_move_x: 0,
            rel_move_y: 0,
        }
    }
}

#[typetag::serde]
impl AdbDevice for AdbMouse {
    fn event(&mut self, event: &AdbEvent) {
        match event {
            AdbEvent::Mouse(me) => self.event_queue.push_back(me.clone()),
            AdbEvent::ReleaseAll => {
                self.event_queue.push_back(MouseEvent {
                    button: Some(false),
                    ..Default::default()
                });
            }
            _ => (),
        }
    }

    fn get_address(&self) -> u8 {
        self.address
    }

    fn reset(&mut self) {
        self.address = Self::INITIAL_ADDRESS;
        self.handler_id = Self::INITIAL_HANDLER_ID;
        self.flush();
    }

    fn flush(&mut self) {
        self.event_queue.clear();
        self.rel_move_x = 0;
        self.rel_move_y = 0;
        self.button = false;
    }

    fn talk(&mut self, reg: u8) -> AdbDeviceResponse {
        match reg {
            0 => {
                if self.get_srq() {
                    while let Some(event) = self.event_queue.pop_front() {
                        if let Some(btn) = event.button {
                            self.button = btn;
                        }
                        if let Some(rel_move) = event.rel_movement {
                            self.rel_move_x =
                                self.rel_move_x.saturating_add(rel_move.0 * MOUSE_FACTOR);
                            self.rel_move_y =
                                self.rel_move_y.saturating_add(rel_move.1 * MOUSE_FACTOR);
                        }
                    }
                    let motion_x = take_from_accumulator(&mut self.rel_move_x, MAX_REL_MOVE) as i8;
                    let motion_y = take_from_accumulator(&mut self.rel_move_y, MAX_REL_MOVE) as i8;

                    AdbDeviceResponse::from_iter(
                        AdbMouseReg0::default()
                            .with_btn(!self.button)
                            .with_x(motion_x)
                            .with_y(motion_y)
                            .to_be_bytes(),
                    )
                } else {
                    AdbDeviceResponse::default()
                }
            }
            3 => AdbDeviceResponse::from_iter(
                AdbReg3::default()
                    .with_exceptional(true)
                    .with_srq(true)
                    .with_address(self.address)
                    .with_handler_id(self.handler_id)
                    .to_be_bytes(),
            ),
            _ => {
                warn!("Unimplemented talk register {}", reg);
                AdbDeviceResponse::default()
            }
        }
    }

    fn listen(&mut self, reg: u8, data: &[u8]) {
        match reg {
            3 => {
                if data.len() < 2 {
                    error!("Listen reg 3 invalid data length: {:02X?}", data);
                    return;
                }

                let value = AdbReg3(u16::from_be_bytes(data[0..2].try_into().unwrap()));
                value.apply_listen(&mut self.address, &mut self.handler_id);
            }
            _ => warn!("Unimplemented listen register {} = {:02X?}", reg, data),
        }
    }

    fn get_srq(&self) -> bool {
        !self.event_queue.is_empty() || self.rel_move_x != 0 || self.rel_move_y != 0
    }
}
